using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FictionWebRazor.Pages.Shared
{
    public class _NotificationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
